<?php
// Definimos dos variables
$var1 = "Hola";
$var2 = 123; // Número entero

// Mostramos las variables
echo "Var1: $var1<br>";
echo "Var2: $var2<br>";
?>