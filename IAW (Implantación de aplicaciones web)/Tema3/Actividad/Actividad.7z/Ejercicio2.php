<?php
for ($i = 1; $i <= 20; $i++) {
    $cuadrado = $i * $i;
    echo "El cuadrado de $i es $cuadrado<br>";
}
?>
